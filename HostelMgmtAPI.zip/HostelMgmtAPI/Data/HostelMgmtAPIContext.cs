﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using HostelMgmtAPI.Model;

namespace HostelMgmtAPI.Data
{
    public class HostelMgmtAPIContext : DbContext
    {
        public HostelMgmtAPIContext (DbContextOptions<HostelMgmtAPIContext> options)
            : base(options)
        {
        }

        public DbSet<HostelMgmtAPI.Model.StudentMaster> StudentMaster { get; set; } = default!;

        public DbSet<HostelMgmtAPI.Model.HostelRoomMaster> HostelRoomMaster { get; set; }
    }
}
