﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HostelMgmtAPI.Migrations
{
    public partial class StudentIdchange : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "studentId",
                table: "HostelRoomMaster",
                newName: "StudentId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "StudentId",
                table: "HostelRoomMaster",
                newName: "studentId");
        }
    }
}
