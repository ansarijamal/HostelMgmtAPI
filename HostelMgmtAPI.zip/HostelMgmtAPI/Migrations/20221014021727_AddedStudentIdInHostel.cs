﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HostelMgmtAPI.Migrations
{
    public partial class AddedStudentIdInHostel : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "studentId",
                table: "HostelRoomMaster",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "studentId",
                table: "HostelRoomMaster");
        }
    }
}
