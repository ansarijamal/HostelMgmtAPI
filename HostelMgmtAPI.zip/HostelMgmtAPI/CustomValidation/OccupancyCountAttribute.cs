﻿using HostelMgmtAPI.Model;
using System.ComponentModel.DataAnnotations;

namespace HostelMgmtAPI.CustomValidation
{
    public class OccupancyCountAttribute: ValidationAttribute
    {
        public OccupancyCountAttribute() : base("{0} should be less than Maximum Occupancy.")
        {

        }

        public override bool IsValid(object? value)
        {
            HostelRoomMaster? hostelRoomMaster = value as HostelRoomMaster;
            if(hostelRoomMaster?.OccupancyCount < hostelRoomMaster?.MaxOccupancy)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
