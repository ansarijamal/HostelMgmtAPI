﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HostelMgmtAPI.Data;
using HostelMgmtAPI.Model;

namespace HostelMgmtAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentMastersController : ControllerBase
    {
        private readonly HostelMgmtAPIContext _context;

        public StudentMastersController(HostelMgmtAPIContext context)
        {
            _context = context;
        }

        // GET: api/StudentMasters
        [HttpGet]
        public async Task<ActionResult<IEnumerable<StudentMaster>>> GetStudentMaster()
        {
            return await _context.StudentMaster.ToListAsync();
        }

        // GET: api/StudentMasters/5
        [HttpGet("{id}")]
        public async Task<ActionResult<StudentMaster>> GetStudentMaster(int id)
        {
            var studentMaster = await _context.StudentMaster.FindAsync(id);

            if (studentMaster == null)
            {
                return NotFound();
            }

            return studentMaster;
        }

        
        // POST: api/StudentMasters
        [HttpPost]
        public async Task<ActionResult<StudentMaster>> PostStudentMaster(StudentMaster studentMaster)
        {
            if (ModelState.IsValid)
            {
                //studentMaster.RoomAllotedTag = 'N';
                _context.StudentMaster.Add(studentMaster);
                await _context.SaveChangesAsync();
            }

            return CreatedAtAction("GetStudentMaster", new { id = studentMaster.StudentId }, studentMaster);
        }
    }
}
