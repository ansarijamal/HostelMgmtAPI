﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HostelMgmtAPI.Data;
using HostelMgmtAPI.Model;

namespace HostelMgmtAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HostelRoomMastersController : ControllerBase
    {
        private readonly HostelMgmtAPIContext _context;

        public HostelRoomMastersController(HostelMgmtAPIContext context)
        {
            _context = context;
        }

        // GET: api/HostelRoomMasters
        [HttpGet]
        public async Task<ActionResult<IEnumerable<HostelRoomMaster>>> GetHostelRoomMaster()
        {
            return await _context.HostelRoomMaster.ToListAsync();
        }

        // GET: api/HostelRoomMasters/M
        [HttpGet("{gender}")]
        public async Task<ActionResult<IEnumerable<HostelRoomMaster>>> GetHostelRoomMaster(char gender)
        {
            return await _context.HostelRoomMaster.Where(hosteldata => hosteldata.Gender == gender).ToListAsync();
        }

        // POST: api/HostelRoomMasters
        [HttpPost]
        public async Task<ActionResult<HostelRoomMaster>> PostHostelRoomMaster(HostelRoomMaster hostelRoomMaster)
        {
            if (ModelState.IsValid)
            {
                if(hostelRoomMaster.OccupancyCount < hostelRoomMaster.MaxOccupancy)
                {
                    StudentMaster SM = await _context.StudentMaster.FindAsync(hostelRoomMaster.StudentId);
                    if (SM.Gender == hostelRoomMaster.Gender)
                    {
                        hostelRoomMaster.OccupancyCount++;
                        _context.HostelRoomMaster.Update(hostelRoomMaster);
                        SM.RoomAllotedTag = 'Y';
                        SM.HostelRoomId = hostelRoomMaster.HostelRoomId;
                        _context.StudentMaster.Update(SM);
                        await _context.SaveChangesAsync();
                    }
                   
                }
                
            }

            return CreatedAtAction("GetHostelRoomMaster", new { id = hostelRoomMaster.HostelRoomId }, hostelRoomMaster);
        }
    }
}
