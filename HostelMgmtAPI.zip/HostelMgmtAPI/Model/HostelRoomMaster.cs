﻿using HostelMgmtAPI.CustomValidation;
using System.ComponentModel.DataAnnotations;

namespace HostelMgmtAPI.Model
{
    public class HostelRoomMaster
    {
        [Key]
        public int HostelRoomId { get; set; }
        public int HostelRoomNo { get; set; }
        public int MaxOccupancy { get; set; }
        public int OccupancyCount { get; set; }
        [Required]
        public char Gender { get; set; }
        public string BuildingName { get; set; }
        public int StudentId { get; set; }

    }
}
