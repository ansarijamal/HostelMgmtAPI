﻿using System.ComponentModel.DataAnnotations;

namespace HostelMgmtAPI.Model
{
    public class StudentMaster
    {
        [Key]
        public int StudentId { get; set; }
        [Required]
        public string StudentName { get; set; }
        [Required]
        public char Gender { get; set; }
        [Required]
        public string Address { get; set; }
        public char RoomAllotedTag { get; set; }
        public DateTime AllotmentDate { get; set; }
        public int HostelRoomId { get; set; }

    }
}
